document.addEventListener("DOMContentLoaded", () => {

    const clients = {
        1: {
            nom: "Jean Dupont",
            decodeurs: [
                { id: 101, nom: "Décodeur #1", actif: true },
                { id: 102, nom: "Décodeur #2", actif: true }
            ]
        },
        2: {
            nom: "Élodie Tremblay",
            decodeurs: []
        },
        3: {
            nom: "Marc Hamel",
            decodeurs: [
                { id: 201, nom: "Décodeur #1", actif: false }
            ]
        }
    };

    const clientItems = document.querySelectorAll(".list-item");
    const decoderList = document.getElementById("decoderList");
    const clientName = document.getElementById("clientName");
    const breadcrumb = document.getElementById("breadcrumb");
    const welcome = document.getElementById("welcomeText");

    clientItems.forEach(item => {
        item.addEventListener("click", () => {

            const id = item.dataset.clientId;
            const client = clients[id];

            if (!client) return;

            welcome.textContent = `Bienvenue, ${client.nom}`;
            clientName.textContent = client.nom;
            breadcrumb.innerHTML = `Vue Client / <b>${client.nom}</b>`;

            renderDecodeurs(client.decodeurs);
        });
    });

    function renderDecodeurs(decodeurs) {
        decoderList.innerHTML = "";

        if (decodeurs.length === 0) {
            decoderList.innerHTML = "<p>Aucun décodeur pour ce client.</p>";
            return;
        }

        decodeurs.forEach(d => {
            const div = document.createElement("div");
            div.className = "decoder";

            div.innerHTML = `
                <div class="decoder-info">
                    <strong>${d.nom}</strong>
                    <small>ID Décodeur #${d.id}</small>
                </div>

                <div class="decoder-actions">
                    <span class="status">
                        <span class="dot"></span>
                        ${d.actif ? "Actif" : "Inactif"}
                    </span>
                </div>
            `;

            decoderList.appendChild(div);
        });
    }
});