document.addEventListener("DOMContentLoaded", () => {

    // =========================
    // Données simulées (base locale)
    // =========================
    let decodeursAttribues = [
        { id: "D001", localisation: "Chambre 101", etat: "En ligne", client: "Hotel A" },
        { id: "D002", localisation: "Chambre 205", etat: "Hors ligne", client: "Hotel B" },
        { id: "D003", localisation: "Lobby", etat: "En ligne", client: "Hotel A" }
    ];

    let decodeursDisponibles = [
        { id: "D010", localisation: "Chambre 300", etat: "En ligne" },
        { id: "D011", localisation: "Salle conf", etat: "Hors ligne" }
    ];

    // =========================
    // Références DOM
    // =========================
    const tabs = document.querySelectorAll(".tab");
    const cards = document.querySelectorAll(".card");

    const attribuesBody = cards[0].querySelector("tbody");
    const disponiblesBody = cards[1].querySelector("tbody");

    const addBtn = document.querySelector(".big-btn.add");
    const deleteBtn = document.querySelector(".big-btn.delete");

    // =========================
    // Gestion des onglets
    // =========================
    tabs[0].addEventListener("click", () => {
        tabs[0].classList.add("active");
        tabs[1].classList.remove("active");
        cards[0].style.display = "block";
        cards[1].style.display = "none";
    });

    tabs[1].addEventListener("click", () => {
        tabs[1].classList.add("active");
        tabs[0].classList.remove("active");
        cards[1].style.display = "block";
        cards[0].style.display = "none";
    });

    // =========================
    // Render tableaux
    // =========================
    function renderTables() {
        attribuesBody.innerHTML = "";
        disponiblesBody.innerHTML = "";

        decodeursAttribues.forEach((d, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${d.id}</td>
                <td>${d.localisation}</td>
                <td class="${d.etat === 'En ligne' ? 'online' : 'offline'}">${d.etat}</td>
                <td>${d.client}</td>
                <td><button class="btn retirer" data-index="${index}">Retirer</button></td>
            `;
            attribuesBody.appendChild(row);
        });

        decodeursDisponibles.forEach((d, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${d.id}</td>
                <td>${d.localisation}</td>
                <td class="${d.etat === 'En ligne' ? 'online' : 'offline'}">${d.etat}</td>
                <td><button class="btn assigner" data-index="${index}">Assigner</button></td>
            `;
            disponiblesBody.appendChild(row);
        });

        attachActionEvents();
    }

    // =========================
    // Attacher les événements
    // =========================
    function attachActionEvents() {

        document.querySelectorAll(".retirer").forEach(btn => {
            btn.addEventListener("click", () => {
                const index = btn.dataset.index;
                retirerDecodeur(index);
            });
        });

        document.querySelectorAll(".assigner").forEach(btn => {
            btn.addEventListener("click", () => {
                const index = btn.dataset.index;
                assignerDecodeur(index);
            });
        });
    }

    // =========================
    // Assigner un décodeur
    // =========================
    function assignerDecodeur(index) {
        const client = prompt("Nom du client :");
        if (!client) return;

        const decodeur = decodeursDisponibles.splice(index, 1)[0];
        decodeur.client = client;

        decodeursAttribues.push(decodeur);
        renderTables();
    }

    // =========================
    // Retirer un décodeur
    // =========================
    function retirerDecodeur(index) {
        const decodeur = decodeursAttribues.splice(index, 1)[0];
        delete decodeur.client;

        decodeursDisponibles.push(decodeur);
        renderTables();
    }

    // =========================
    // Ajouter un décodeur
    // =========================
    addBtn.addEventListener("click", () => {
        const id = prompt("ID du décodeur :");
        const loc = prompt("Localisation :");
        const etat = prompt("État (En ligne / Hors ligne) :");

        if (!id || !loc) return;

        decodeursDisponibles.push({
            id,
            localisation: loc,
            etat: etat || "Hors ligne"
        });

        renderTables();
    });

    // =========================
    // Supprimer un décodeur
    // =========================
    deleteBtn.addEventListener("click", () => {
        const id = prompt("ID du décodeur à supprimer :");

        decodeursAttribues = decodeursAttribues.filter(d => d.id !== id);
        decodeursDisponibles = decodeursDisponibles.filter(d => d.id !== id);

        renderTables();
    });

    // =========================
    // Initialisation
    // =========================
    renderTables();

    // Masquer le deuxième tableau au démarrage
    cards[1].style.display = "none";
});